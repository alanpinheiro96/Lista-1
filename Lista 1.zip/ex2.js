// Faça um algoritmo que leia um número, calcule e mostre o equivalente a 30% dele.

// Entrada

var n1 = parseInt(prompt("Digite um número"));

// Processamento

var r = (n1 / 100) * 30;

// Saída

alert("O resultado dos 30% de " + n1 + " é: " + r);