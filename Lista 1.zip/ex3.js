// Faça um algoritmo que leia 5 números, calcule e mostre a média;

// Entrada

var n1 = parseInt(prompt("Digite um número"));

var n2 = parseInt(prompt("Digite um número"));

var n3 = parseInt(prompt("Digite um número"));

var n4 = parseInt(prompt("Digite um número"));

var n5 = parseInt(prompt("Digite um número"));

// Processamento

var r = (n1 + n2 + n3 + n4 + n5) / 5;

// Saída

alert("A Média é: " + r);
