//Faça um algoritmo que leia 4 números, calcule e mostre a soma dos três primeiros números multiplicado pelo último número;

// Entrada

var n1 = parseInt(prompt("Digite um número"));

var n2 = parseInt(prompt("Digite um número"));

var n3 = parseInt(prompt("Digite um número"));

var n4 = parseInt(prompt("Digite um número"));

// Processamento

var r = (n1 + n2 + n3) * n4;

// Saída

alert("O resultado do exercicio é: " + r);