/* 
1)	Faça um algoritmo que leia 4 números, calcule e mostre a soma dos três primeiros números multiplicado pelo último número;

2)	Faça um algoritmo que leia um número, calcule e mostre o equivalente a 30% dele.

3)	Faça um algoritmo que leia 5 números, calcule e mostre a média;

4)	Um vendedor recebe, por mês, um salário fixo e mais um adicional de 20% do valor das vendas que ele efetuou. 
Faça um algoritmo que leia o salário fixo e o valor de venda do mês, calcule e mostre o salário final do vendedor. 

5)	Um banco concede um valor para empréstimo de até 60% do saldo médio anual do cliente. Faça um algoritmo que leia o 
saldo médio do cliente, calcule e mostre o valor disponível para empréstimo.
*/